﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.lblCompanyName = New System.Windows.Forms.Label()
        Me.lblFirstName = New System.Windows.Forms.Label()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.lblLastName = New System.Windows.Forms.Label()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.lblStreetAddress = New System.Windows.Forms.Label()
        Me.txtStreetAddress = New System.Windows.Forms.TextBox()
        Me.lblAptSuite = New System.Windows.Forms.Label()
        Me.txtAptSuite = New System.Windows.Forms.TextBox()
        Me.lblPhone = New System.Windows.Forms.Label()
        Me.txtPhone = New System.Windows.Forms.TextBox()
        Me.lblEmail = New System.Windows.Forms.Label()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.lblSubcribe = New System.Windows.Forms.Label()
        Me.cbSubscribe = New System.Windows.Forms.CheckBox()
        Me.lblMeal1 = New System.Windows.Forms.Label()
        Me.cbbFirstMeal = New System.Windows.Forms.ComboBox()
        Me.lblSecondMeal = New System.Windows.Forms.Label()
        Me.cbSecondMeal = New System.Windows.Forms.ComboBox()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblCompanyName
        '
        Me.lblCompanyName.AutoSize = True
        Me.lblCompanyName.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCompanyName.Location = New System.Drawing.Point(254, 9)
        Me.lblCompanyName.Name = "lblCompanyName"
        Me.lblCompanyName.Size = New System.Drawing.Size(301, 37)
        Me.lblCompanyName.TabIndex = 0
        Me.lblCompanyName.Text = "The Vegan Wagon"
        Me.lblCompanyName.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblFirstName
        '
        Me.lblFirstName.AutoSize = True
        Me.lblFirstName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFirstName.Location = New System.Drawing.Point(22, 99)
        Me.lblFirstName.Name = "lblFirstName"
        Me.lblFirstName.Size = New System.Drawing.Size(73, 16)
        Me.lblFirstName.TabIndex = 1
        Me.lblFirstName.Text = "First Name"
        '
        'txtFirstName
        '
        Me.txtFirstName.Location = New System.Drawing.Point(129, 95)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(147, 20)
        Me.txtFirstName.TabIndex = 1
        '
        'lblLastName
        '
        Me.lblLastName.AutoSize = True
        Me.lblLastName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLastName.Location = New System.Drawing.Point(22, 137)
        Me.lblLastName.Name = "lblLastName"
        Me.lblLastName.Size = New System.Drawing.Size(73, 16)
        Me.lblLastName.TabIndex = 3
        Me.lblLastName.Text = "Last Name"
        '
        'txtLastName
        '
        Me.txtLastName.Location = New System.Drawing.Point(129, 133)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(147, 20)
        Me.txtLastName.TabIndex = 2
        '
        'lblStreetAddress
        '
        Me.lblStreetAddress.AutoSize = True
        Me.lblStreetAddress.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStreetAddress.Location = New System.Drawing.Point(22, 177)
        Me.lblStreetAddress.Name = "lblStreetAddress"
        Me.lblStreetAddress.Size = New System.Drawing.Size(97, 16)
        Me.lblStreetAddress.TabIndex = 5
        Me.lblStreetAddress.Text = "Street Address"
        '
        'txtStreetAddress
        '
        Me.txtStreetAddress.Location = New System.Drawing.Point(129, 173)
        Me.txtStreetAddress.Name = "txtStreetAddress"
        Me.txtStreetAddress.Size = New System.Drawing.Size(272, 20)
        Me.txtStreetAddress.TabIndex = 3
        '
        'lblAptSuite
        '
        Me.lblAptSuite.AutoSize = True
        Me.lblAptSuite.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAptSuite.Location = New System.Drawing.Point(22, 215)
        Me.lblAptSuite.Name = "lblAptSuite"
        Me.lblAptSuite.Size = New System.Drawing.Size(62, 16)
        Me.lblAptSuite.TabIndex = 7
        Me.lblAptSuite.Text = "Apt/Suite"
        '
        'txtAptSuite
        '
        Me.txtAptSuite.Location = New System.Drawing.Point(129, 211)
        Me.txtAptSuite.Name = "txtAptSuite"
        Me.txtAptSuite.Size = New System.Drawing.Size(76, 20)
        Me.txtAptSuite.TabIndex = 4
        '
        'lblPhone
        '
        Me.lblPhone.AutoSize = True
        Me.lblPhone.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPhone.Location = New System.Drawing.Point(22, 253)
        Me.lblPhone.Name = "lblPhone"
        Me.lblPhone.Size = New System.Drawing.Size(98, 16)
        Me.lblPhone.TabIndex = 9
        Me.lblPhone.Text = "Phone Number"
        '
        'txtPhone
        '
        Me.txtPhone.Location = New System.Drawing.Point(129, 252)
        Me.txtPhone.Name = "txtPhone"
        Me.txtPhone.Size = New System.Drawing.Size(116, 20)
        Me.txtPhone.TabIndex = 5
        '
        'lblEmail
        '
        Me.lblEmail.AutoSize = True
        Me.lblEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmail.Location = New System.Drawing.Point(22, 293)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(45, 16)
        Me.lblEmail.TabIndex = 11
        Me.lblEmail.Text = "Email "
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(129, 289)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(177, 20)
        Me.txtEmail.TabIndex = 6
        '
        'lblSubcribe
        '
        Me.lblSubcribe.AutoSize = True
        Me.lblSubcribe.Location = New System.Drawing.Point(25, 331)
        Me.lblSubcribe.Name = "lblSubcribe"
        Me.lblSubcribe.Size = New System.Drawing.Size(306, 13)
        Me.lblSubcribe.TabIndex = 13
        Me.lblSubcribe.Text = "Please check here if you would like to subscribe to our services"
        '
        'cbSubscribe
        '
        Me.cbSubscribe.AutoSize = True
        Me.cbSubscribe.Location = New System.Drawing.Point(347, 327)
        Me.cbSubscribe.Name = "cbSubscribe"
        Me.cbSubscribe.Size = New System.Drawing.Size(73, 17)
        Me.cbSubscribe.TabIndex = 9
        Me.cbSubscribe.Text = "Subscribe"
        Me.cbSubscribe.UseVisualStyleBackColor = True
        '
        'lblMeal1
        '
        Me.lblMeal1.AutoSize = True
        Me.lblMeal1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMeal1.Location = New System.Drawing.Point(474, 99)
        Me.lblMeal1.Name = "lblMeal1"
        Me.lblMeal1.Size = New System.Drawing.Size(111, 16)
        Me.lblMeal1.TabIndex = 15
        Me.lblMeal1.Text = "First Meal Choice"
        '
        'cbbFirstMeal
        '
        Me.cbbFirstMeal.FormattingEnabled = True
        Me.cbbFirstMeal.Items.AddRange(New Object() {"Easy Peanut Noodles", "Mango Curry Chickpeas", "Vegan Thai Soup"})
        Me.cbbFirstMeal.Location = New System.Drawing.Point(619, 94)
        Me.cbbFirstMeal.Name = "cbbFirstMeal"
        Me.cbbFirstMeal.Size = New System.Drawing.Size(121, 21)
        Me.cbbFirstMeal.TabIndex = 7
        '
        'lblSecondMeal
        '
        Me.lblSecondMeal.AutoSize = True
        Me.lblSecondMeal.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSecondMeal.Location = New System.Drawing.Point(477, 139)
        Me.lblSecondMeal.Name = "lblSecondMeal"
        Me.lblSecondMeal.Size = New System.Drawing.Size(133, 16)
        Me.lblSecondMeal.TabIndex = 17
        Me.lblSecondMeal.Text = "Second Meal Choice"
        '
        'cbSecondMeal
        '
        Me.cbSecondMeal.FormattingEnabled = True
        Me.cbSecondMeal.Items.AddRange(New Object() {"Vegan Fried Chicken", "Tofu Banh", "Stuffed Peppers"})
        Me.cbSecondMeal.Location = New System.Drawing.Point(619, 132)
        Me.cbSecondMeal.Name = "cbSecondMeal"
        Me.cbSecondMeal.Size = New System.Drawing.Size(121, 21)
        Me.cbSecondMeal.TabIndex = 8
        '
        'btnSubmit
        '
        Me.btnSubmit.Location = New System.Drawing.Point(347, 397)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(75, 23)
        Me.btnSubmit.TabIndex = 10
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(458, 396)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(75, 23)
        Me.btnClose.TabIndex = 11
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(584, 396)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 12
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.cbSecondMeal)
        Me.Controls.Add(Me.lblSecondMeal)
        Me.Controls.Add(Me.cbbFirstMeal)
        Me.Controls.Add(Me.lblMeal1)
        Me.Controls.Add(Me.cbSubscribe)
        Me.Controls.Add(Me.lblSubcribe)
        Me.Controls.Add(Me.txtEmail)
        Me.Controls.Add(Me.lblEmail)
        Me.Controls.Add(Me.txtPhone)
        Me.Controls.Add(Me.lblPhone)
        Me.Controls.Add(Me.txtAptSuite)
        Me.Controls.Add(Me.lblAptSuite)
        Me.Controls.Add(Me.txtStreetAddress)
        Me.Controls.Add(Me.lblStreetAddress)
        Me.Controls.Add(Me.txtLastName)
        Me.Controls.Add(Me.lblLastName)
        Me.Controls.Add(Me.txtFirstName)
        Me.Controls.Add(Me.lblFirstName)
        Me.Controls.Add(Me.lblCompanyName)
        Me.Name = "Form1"
        Me.Text = "The Vegan Wagon"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblCompanyName As Label
    Friend WithEvents lblFirstName As Label
    Friend WithEvents txtFirstName As TextBox
    Friend WithEvents lblLastName As Label
    Friend WithEvents txtLastName As TextBox
    Friend WithEvents lblStreetAddress As Label
    Friend WithEvents txtStreetAddress As TextBox
    Friend WithEvents lblAptSuite As Label
    Friend WithEvents txtAptSuite As TextBox
    Friend WithEvents lblPhone As Label
    Friend WithEvents txtPhone As TextBox
    Friend WithEvents lblEmail As Label
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents lblSubcribe As Label
    Friend WithEvents cbSubscribe As CheckBox
    Friend WithEvents lblMeal1 As Label
    Friend WithEvents cbbFirstMeal As ComboBox
    Friend WithEvents lblSecondMeal As Label
    Friend WithEvents cbSecondMeal As ComboBox
    Friend WithEvents btnSubmit As Button
    Friend WithEvents btnClose As Button
    Friend WithEvents btnClear As Button
End Class
