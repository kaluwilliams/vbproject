﻿Imports System.Data.OleDb
Public Class Form1
    Dim provider As String
    Dim dataFile As String
    Dim connString As String
    Dim myConnection As OleDbConnection = New OleDbConnection
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtFirstName.Clear()
        txtLastName.Clear()
        txtPhone.Clear()
        txtStreetAddress.Clear()
        txtAptSuite.Clear()
        cbSubscribe.Checked = False
        txtEmail.Clear()
        cbbFirstMeal.SelectedIndex = -1
        cbSecondMeal.SelectedIndex = -1


    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Close()

    End Sub

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        provider = "Provider=Microsoft.Jet.OLEDB.4.0;Data source="
        dataFile = "C:\Users\Kalu\source\repos\The Vegan Wagon Project\Database vegan wagon2.mdb"
        connString = provider & dataFile
        myConnection.ConnectionString = connString
        myConnection.Open()
        If myConnection.State = ConnectionState.Open Then
            myConnection.Close()
        End If
        Dim str As String
        str = "insert into Item ([First Name],[Last Name],[Street Address],[Apt Suite],[Phone Number],[Email Address],[Subscribe],[First Meal],[Second Meal]) Value (?,?,?,?,?,?,?,?,?)"
        Dim cmd As OleDbCommand = New OleDbCommand(str, myConnection)
        cmd.Parameters.Add(New OleDbParameter("First Name", CType(txtFirstName.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("Last Name", CType(txtLastName.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("Street Address", CType(txtStreetAddress.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("Apt Suite", CType(txtAptSuite.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("Phone Number", CType(txtPhone.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("Email Address", CType(txtEmail.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("Subscribe", CType(cbSubscribe.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("First Meal", CType(cbbFirstMeal.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("Second Meal", CType(txtFirstName.Text, String)))


        Try
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            myConnection.Close()
            txtFirstName.Clear()
            txtLastName.Clear()
            txtPhone.Clear()
            txtStreetAddress.Clear()
            txtAptSuite.Clear()
            cbSubscribe.Checked = False
            txtEmail.Clear()
            cbbFirstMeal.SelectedIndex = -1
            cbSecondMeal.SelectedIndex = -1
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub
End Class
